package com.hms.dao;

import com.hms.model.Bill;
import com.hms.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Data access object for the bills table.
 */
public class BillDAO {

    private static final Logger LOGGER = Logger.getLogger(BillDAO.class.getName());

    public boolean generateBill(Bill bill) {
        String sql = "INSERT INTO bills (patient_id, appointment_id, consultation_fee, medicine_charges, other_charges, total_amount, payment_status, bill_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, bill.getPatientId());
            if (bill.getAppointmentId() == null) {
                ps.setNull(2, Types.INTEGER);
            } else {
                ps.setInt(2, bill.getAppointmentId());
            }
            ps.setBigDecimal(3, bill.getConsultationFee());
            ps.setBigDecimal(4, bill.getMedicineCharges());
            ps.setBigDecimal(5, bill.getOtherCharges());
            ps.setBigDecimal(6, bill.getTotalAmount());
            ps.setString(7, bill.getPaymentStatus() == null ? "UNPAID" : bill.getPaymentStatus());
            ps.setDate(8, bill.getBillDate());
            int rows = ps.executeUpdate();
            if (rows > 0) {
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) {
                        bill.setBillId(keys.getInt(1));
                    }
                }
                return true;
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error generating bill.", e);
        }
        return false;
    }

    public Bill getBillById(int billId) {
        String sql = "SELECT * FROM bills WHERE bill_id = ?";
        try (PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, billId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return map(rs);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error fetching bill by id.", e);
        }
        return null;
    }

    public List<Bill> getBillsByPatient(int patientId) {
        List<Bill> list = new ArrayList<>();
        String sql = "SELECT * FROM bills WHERE patient_id = ? ORDER BY bill_date DESC";
        try (PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, patientId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(map(rs));
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error fetching bills by patient.", e);
        }
        return list;
    }

    private Bill map(ResultSet rs) throws SQLException {
        int appointmentId = rs.getInt("appointment_id");
        Integer appointmentIdBoxed = rs.wasNull() ? null : appointmentId;
        return new Bill(
            rs.getInt("bill_id"),
            rs.getInt("patient_id"),
            appointmentIdBoxed,
            rs.getBigDecimal("consultation_fee"),
            rs.getBigDecimal("medicine_charges"),
            rs.getBigDecimal("other_charges"),
            rs.getBigDecimal("total_amount"),
            rs.getString("payment_status"),
            rs.getDate("bill_date")
        );
    }
}
