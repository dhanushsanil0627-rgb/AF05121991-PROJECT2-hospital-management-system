package com.hms.dao;

import com.hms.model.MedicalRecord;
import com.hms.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Data access object for the medical_records table.
 */
public class MedicalRecordDAO {

    private static final Logger LOGGER = Logger.getLogger(MedicalRecordDAO.class.getName());

    public boolean addMedicalRecord(MedicalRecord record) {
        String sql = "INSERT INTO medical_records (patient_id, doctor_id, diagnosis, treatment, notes, record_date) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, record.getPatientId());
            ps.setInt(2, record.getDoctorId());
            ps.setString(3, record.getDiagnosis());
            ps.setString(4, record.getTreatment());
            ps.setString(5, record.getNotes());
            ps.setDate(6, record.getRecordDate());
            int rows = ps.executeUpdate();
            if (rows > 0) {
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) {
                        record.setRecordId(keys.getInt(1));
                    }
                }
                return true;
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error adding medical record.", e);
        }
        return false;
    }

    public List<MedicalRecord> getRecordsByPatient(int patientId) {
        List<MedicalRecord> list = new ArrayList<>();
        String sql = "SELECT * FROM medical_records WHERE patient_id = ? ORDER BY record_date DESC";
        try (PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, patientId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(map(rs));
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error fetching medical records by patient.", e);
        }
        return list;
    }

    private MedicalRecord map(ResultSet rs) throws SQLException {
        return new MedicalRecord(
            rs.getInt("record_id"),
            rs.getInt("patient_id"),
            rs.getInt("doctor_id"),
            rs.getString("diagnosis"),
            rs.getString("treatment"),
            rs.getString("notes"),
            rs.getDate("record_date")
        );
    }
}
