package com.hms.model;

import java.sql.Date;

/**
 * Medical record (EHR) model class.
 */
public class MedicalRecord {

    private int recordId;
    private int patientId;
    private int doctorId;
    private String diagnosis;
    private String treatment;
    private String notes;
    private Date recordDate;

    public MedicalRecord() {}

    public MedicalRecord(int patientId, int doctorId, String diagnosis, String treatment,
                         String notes, Date recordDate) {
        this.patientId = patientId;
        this.doctorId = doctorId;
        this.diagnosis = diagnosis;
        this.treatment = treatment;
        this.notes = notes;
        this.recordDate = recordDate;
    }

    public MedicalRecord(int recordId, int patientId, int doctorId, String diagnosis,
                         String treatment, String notes, Date recordDate) {
        this.recordId = recordId;
        this.patientId = patientId;
        this.doctorId = doctorId;
        this.diagnosis = diagnosis;
        this.treatment = treatment;
        this.notes = notes;
        this.recordDate = recordDate;
    }

    public int getRecordId() { return recordId; }
    public void setRecordId(int recordId) { this.recordId = recordId; }

    public int getPatientId() { return patientId; }
    public void setPatientId(int patientId) { this.patientId = patientId; }

    public int getDoctorId() { return doctorId; }
    public void setDoctorId(int doctorId) { this.doctorId = doctorId; }

    public String getDiagnosis() { return diagnosis; }
    public void setDiagnosis(String diagnosis) { this.diagnosis = diagnosis; }

    public String getTreatment() { return treatment; }
    public void setTreatment(String treatment) { this.treatment = treatment; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }

    public Date getRecordDate() { return recordDate; }
    public void setRecordDate(Date recordDate) { this.recordDate = recordDate; }

    @Override
    public String toString() {
        return String.format(
            "MedicalRecord{id=%d, patientId=%d, doctorId=%d, diagnosis='%s', treatment='%s', notes='%s', date=%s}",
            recordId, patientId, doctorId, diagnosis, treatment, notes, recordDate);
    }
}
