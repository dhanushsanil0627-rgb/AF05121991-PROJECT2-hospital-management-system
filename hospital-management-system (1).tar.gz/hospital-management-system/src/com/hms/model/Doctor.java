package com.hms.model;

/**
 * Doctor model class.
 */
public class Doctor {

    private int doctorId;
    private String name;
    private String specialization;
    private String phone;
    private String email;

    public Doctor() {}

    public Doctor(String name, String specialization, String phone, String email) {
        this.name = name;
        this.specialization = specialization;
        this.phone = phone;
        this.email = email;
    }

    public Doctor(int doctorId, String name, String specialization, String phone, String email) {
        this.doctorId = doctorId;
        this.name = name;
        this.specialization = specialization;
        this.phone = phone;
        this.email = email;
    }

    public int getDoctorId() { return doctorId; }
    public void setDoctorId(int doctorId) { this.doctorId = doctorId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getSpecialization() { return specialization; }
    public void setSpecialization(String specialization) { this.specialization = specialization; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    @Override
    public String toString() {
        return String.format("Doctor{id=%d, name='%s', specialization='%s', phone='%s', email='%s'}",
                doctorId, name, specialization, phone, email);
    }
}
