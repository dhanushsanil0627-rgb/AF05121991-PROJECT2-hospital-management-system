package com.hms.model;

import java.math.BigDecimal;
import java.sql.Date;

/**
 * Bill model class.
 */
public class Bill {

    private int billId;
    private int patientId;
    private Integer appointmentId; // nullable
    private BigDecimal consultationFee;
    private BigDecimal medicineCharges;
    private BigDecimal otherCharges;
    private BigDecimal totalAmount;
    private String paymentStatus; // PAID / UNPAID
    private Date billDate;

    public Bill() {}

    public Bill(int patientId, Integer appointmentId, BigDecimal consultationFee,
                BigDecimal medicineCharges, BigDecimal otherCharges,
                BigDecimal totalAmount, String paymentStatus, Date billDate) {
        this.patientId = patientId;
        this.appointmentId = appointmentId;
        this.consultationFee = consultationFee;
        this.medicineCharges = medicineCharges;
        this.otherCharges = otherCharges;
        this.totalAmount = totalAmount;
        this.paymentStatus = paymentStatus;
        this.billDate = billDate;
    }

    public Bill(int billId, int patientId, Integer appointmentId, BigDecimal consultationFee,
                BigDecimal medicineCharges, BigDecimal otherCharges,
                BigDecimal totalAmount, String paymentStatus, Date billDate) {
        this.billId = billId;
        this.patientId = patientId;
        this.appointmentId = appointmentId;
        this.consultationFee = consultationFee;
        this.medicineCharges = medicineCharges;
        this.otherCharges = otherCharges;
        this.totalAmount = totalAmount;
        this.paymentStatus = paymentStatus;
        this.billDate = billDate;
    }

    public int getBillId() { return billId; }
    public void setBillId(int billId) { this.billId = billId; }

    public int getPatientId() { return patientId; }
    public void setPatientId(int patientId) { this.patientId = patientId; }

    public Integer getAppointmentId() { return appointmentId; }
    public void setAppointmentId(Integer appointmentId) { this.appointmentId = appointmentId; }

    public BigDecimal getConsultationFee() { return consultationFee; }
    public void setConsultationFee(BigDecimal consultationFee) { this.consultationFee = consultationFee; }

    public BigDecimal getMedicineCharges() { return medicineCharges; }
    public void setMedicineCharges(BigDecimal medicineCharges) { this.medicineCharges = medicineCharges; }

    public BigDecimal getOtherCharges() { return otherCharges; }
    public void setOtherCharges(BigDecimal otherCharges) { this.otherCharges = otherCharges; }

    public BigDecimal getTotalAmount() { return totalAmount; }
    public void setTotalAmount(BigDecimal totalAmount) { this.totalAmount = totalAmount; }

    public String getPaymentStatus() { return paymentStatus; }
    public void setPaymentStatus(String paymentStatus) { this.paymentStatus = paymentStatus; }

    public Date getBillDate() { return billDate; }
    public void setBillDate(Date billDate) { this.billDate = billDate; }

    @Override
    public String toString() {
        return String.format(
            "Bill{id=%d, patientId=%d, appointmentId=%s, consultation=%s, medicine=%s, other=%s, total=%s, status=%s, date=%s}",
            billId, patientId, appointmentId, consultationFee, medicineCharges, otherCharges, totalAmount, paymentStatus, billDate);
    }
}
