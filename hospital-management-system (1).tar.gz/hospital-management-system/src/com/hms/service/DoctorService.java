package com.hms.service;

import com.hms.dao.DoctorDAO;
import com.hms.model.Doctor;

import java.util.List;

/**
 * Business-layer service for Doctor operations.
 */
public class DoctorService {

    private final DoctorDAO doctorDAO = new DoctorDAO();

    public boolean addDoctor(Doctor doctor) {
        validate(doctor);
        return doctorDAO.addDoctor(doctor);
    }

    public List<Doctor> getAllDoctors() {
        return doctorDAO.getAllDoctors();
    }

    public Doctor getDoctorById(int id) {
        if (id <= 0) throw new IllegalArgumentException("Doctor ID must be positive.");
        return doctorDAO.getDoctorById(id);
    }

    public boolean updateDoctor(Doctor doctor) {
        if (doctor.getDoctorId() <= 0) throw new IllegalArgumentException("Doctor ID must be positive.");
        validate(doctor);
        return doctorDAO.updateDoctor(doctor);
    }

    public boolean deleteDoctor(int id) {
        if (id <= 0) throw new IllegalArgumentException("Doctor ID must be positive.");
        return doctorDAO.deleteDoctor(id);
    }

    public int countDoctors() {
        return doctorDAO.countDoctors();
    }

    private void validate(Doctor doctor) {
        if (doctor == null) throw new IllegalArgumentException("Doctor cannot be null.");
        if (doctor.getName() == null || doctor.getName().trim().isEmpty())
            throw new IllegalArgumentException("Name is required.");
        if (doctor.getSpecialization() == null || doctor.getSpecialization().trim().isEmpty())
            throw new IllegalArgumentException("Specialization is required.");
        if (doctor.getPhone() == null || !doctor.getPhone().matches("\\d{10,15}"))
            throw new IllegalArgumentException("Phone must be 10-15 digits.");
        if (doctor.getEmail() != null && !doctor.getEmail().isEmpty()
                && !doctor.getEmail().matches("^[\\w.-]+@[\\w.-]+\\.[A-Za-z]{2,}$"))
            throw new IllegalArgumentException("Email format is invalid.");
    }
}
