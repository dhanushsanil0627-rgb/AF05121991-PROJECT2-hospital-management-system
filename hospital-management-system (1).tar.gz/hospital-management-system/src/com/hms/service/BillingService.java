package com.hms.service;

import com.hms.dao.BillDAO;
import com.hms.model.Bill;

import java.math.BigDecimal;
import java.util.List;

/**
 * Business-layer service for Billing operations.
 * Computes the total amount from individual charges before persisting.
 */
public class BillingService {

    private final BillDAO billDAO = new BillDAO();

    public boolean generateBill(Bill bill) {
        validate(bill);
        BigDecimal total = bill.getConsultationFee()
                .add(bill.getMedicineCharges())
                .add(bill.getOtherCharges());
        bill.setTotalAmount(total);
        return billDAO.generateBill(bill);
    }

    public Bill getBillById(int billId) {
        if (billId <= 0) throw new IllegalArgumentException("Bill ID must be positive.");
        return billDAO.getBillById(billId);
    }

    public List<Bill> getBillsByPatient(int patientId) {
        if (patientId <= 0) throw new IllegalArgumentException("Patient ID must be positive.");
        return billDAO.getBillsByPatient(patientId);
    }

    private void validate(Bill bill) {
        if (bill == null) throw new IllegalArgumentException("Bill cannot be null.");
        if (bill.getPatientId() <= 0) throw new IllegalArgumentException("Patient ID must be positive.");
        if (bill.getConsultationFee() == null || bill.getConsultationFee().signum() < 0)
            throw new IllegalArgumentException("Consultation fee must be >= 0.");
        if (bill.getMedicineCharges() == null || bill.getMedicineCharges().signum() < 0)
            throw new IllegalArgumentException("Medicine charges must be >= 0.");
        if (bill.getOtherCharges() == null || bill.getOtherCharges().signum() < 0)
            throw new IllegalArgumentException("Other charges must be >= 0.");
        if (bill.getBillDate() == null) throw new IllegalArgumentException("Bill date is required.");
    }
}
