package com.hms.service;

import com.hms.dao.AppointmentDAO;
import com.hms.model.Appointment;

import java.util.List;

/**
 * Business-layer service for Appointment operations.
 */
public class AppointmentService {

    private final AppointmentDAO appointmentDAO = new AppointmentDAO();

    public boolean bookAppointment(Appointment appointment) {
        validate(appointment);
        return appointmentDAO.bookAppointment(appointment);
    }

    public List<Appointment> getAllAppointments() {
        return appointmentDAO.getAllAppointments();
    }

    public Appointment getAppointmentById(int id) {
        if (id <= 0) throw new IllegalArgumentException("Appointment ID must be positive.");
        return appointmentDAO.getAppointmentById(id);
    }

    public boolean cancelAppointment(int id) {
        if (id <= 0) throw new IllegalArgumentException("Appointment ID must be positive.");
        return appointmentDAO.cancelAppointment(id);
    }

    public int[] getAppointmentSummary() {
        return appointmentDAO.getAppointmentSummary();
    }

    private void validate(Appointment appointment) {
        if (appointment == null) throw new IllegalArgumentException("Appointment cannot be null.");
        if (appointment.getPatientId() <= 0) throw new IllegalArgumentException("Patient ID must be positive.");
        if (appointment.getDoctorId() <= 0) throw new IllegalArgumentException("Doctor ID must be positive.");
        if (appointment.getAppointmentDate() == null) throw new IllegalArgumentException("Date is required.");
        if (appointment.getAppointmentTime() == null) throw new IllegalArgumentException("Time is required.");
    }
}
