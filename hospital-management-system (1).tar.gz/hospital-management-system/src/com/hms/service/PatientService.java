package com.hms.service;

import com.hms.dao.PatientDAO;
import com.hms.model.Patient;

import java.util.List;

/**
 * Business-layer service for Patient operations.
 * Handles validation and delegates to the DAO.
 */
public class PatientService {

    private final PatientDAO patientDAO = new PatientDAO();

    public boolean addPatient(Patient patient) {
        validate(patient);
        return patientDAO.addPatient(patient);
    }

    public List<Patient> getAllPatients() {
        return patientDAO.getAllPatients();
    }

    public Patient getPatientById(int id) {
        if (id <= 0) throw new IllegalArgumentException("Patient ID must be positive.");
        return patientDAO.getPatientById(id);
    }

    public boolean updatePatient(Patient patient) {
        if (patient.getPatientId() <= 0) throw new IllegalArgumentException("Patient ID must be positive.");
        validate(patient);
        return patientDAO.updatePatient(patient);
    }

    public boolean deletePatient(int id) {
        if (id <= 0) throw new IllegalArgumentException("Patient ID must be positive.");
        return patientDAO.deletePatient(id);
    }

    public int countPatients() {
        return patientDAO.countPatients();
    }

    private void validate(Patient patient) {
        if (patient == null) throw new IllegalArgumentException("Patient cannot be null.");
        if (patient.getName() == null || patient.getName().trim().isEmpty())
            throw new IllegalArgumentException("Name is required.");
        if (patient.getAge() <= 0 || patient.getAge() > 130)
            throw new IllegalArgumentException("Age must be between 1 and 130.");
        if (patient.getGender() == null || !patient.getGender().matches("[MFO]"))
            throw new IllegalArgumentException("Gender must be M, F, or O.");
        if (patient.getPhone() == null || !patient.getPhone().matches("\\d{10,15}"))
            throw new IllegalArgumentException("Phone must be 10-15 digits.");
    }
}
