package com.hms.service;

import com.hms.dao.MedicalRecordDAO;
import com.hms.model.MedicalRecord;

import java.util.List;

/**
 * Business-layer service for Medical Record operations.
 */
public class MedicalRecordService {

    private final MedicalRecordDAO medicalRecordDAO = new MedicalRecordDAO();

    public boolean addMedicalRecord(MedicalRecord record) {
        validate(record);
        return medicalRecordDAO.addMedicalRecord(record);
    }

    public List<MedicalRecord> getRecordsByPatient(int patientId) {
        if (patientId <= 0) throw new IllegalArgumentException("Patient ID must be positive.");
        return medicalRecordDAO.getRecordsByPatient(patientId);
    }

    private void validate(MedicalRecord record) {
        if (record == null) throw new IllegalArgumentException("Medical record cannot be null.");
        if (record.getPatientId() <= 0) throw new IllegalArgumentException("Patient ID must be positive.");
        if (record.getDoctorId() <= 0) throw new IllegalArgumentException("Doctor ID must be positive.");
        if (record.getDiagnosis() == null || record.getDiagnosis().trim().isEmpty())
            throw new IllegalArgumentException("Diagnosis is required.");
        if (record.getTreatment() == null || record.getTreatment().trim().isEmpty())
            throw new IllegalArgumentException("Treatment is required.");
        if (record.getRecordDate() == null) throw new IllegalArgumentException("Record date is required.");
    }
}
