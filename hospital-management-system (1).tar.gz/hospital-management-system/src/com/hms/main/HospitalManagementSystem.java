package com.hms.main;

import com.hms.model.*;
import com.hms.service.*;
import com.hms.util.DBConnection;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Time;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Menu-driven console UI for the Hospital Management System.
 */
public class HospitalManagementSystem {

    private static final Logger LOGGER = Logger.getLogger(HospitalManagementSystem.class.getName());

    private final Scanner scanner = new Scanner(System.in);

    private final PatientService       patientService       = new PatientService();
    private final DoctorService        doctorService        = new DoctorService();
    private final AppointmentService   appointmentService   = new AppointmentService();
    private final MedicalRecordService medicalRecordService = new MedicalRecordService();
    private final BillingService       billingService       = new BillingService();

    public static void main(String[] args) {
        new HospitalManagementSystem().start();
    }

    public void start() {
        boolean running = true;
        while (running) {
            printMainMenu();
            int choice = readInt("Enter choice: ");
            switch (choice) {
                case 1: patientMenu();        break;
                case 2: doctorMenu();         break;
                case 3: appointmentMenu();    break;
                case 4: medicalRecordMenu();  break;
                case 5: billingMenu();        break;
                case 6: reportsMenu();        break;
                case 0:
                    running = false;
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
        DBConnection.closeConnection();
        scanner.close();
    }

    // ---------------- Menus ----------------

    private void printMainMenu() {
        System.out.println("\n========== HOSPITAL MANAGEMENT SYSTEM ==========");
        System.out.println("1. Patient Management");
        System.out.println("2. Doctor Management");
        System.out.println("3. Appointment Management");
        System.out.println("4. Medical Records");
        System.out.println("5. Billing");
        System.out.println("6. Reports");
        System.out.println("0. Exit");
        System.out.println("=================================================");
    }

    private void patientMenu() {
        System.out.println("\n--- Patient Management ---");
        System.out.println("1. Add Patient");
        System.out.println("2. View All Patients");
        System.out.println("3. Search Patient by ID");
        System.out.println("4. Update Patient");
        System.out.println("5. Delete Patient");
        System.out.println("0. Back");
        int choice = readInt("Choice: ");
        try {
            switch (choice) {
                case 1: addPatient();         break;
                case 2: viewAllPatients();    break;
                case 3: searchPatient();      break;
                case 4: updatePatient();      break;
                case 5: deletePatient();      break;
                case 0: return;
                default: System.out.println("Invalid choice.");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Validation error: " + e.getMessage());
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Unexpected error in patient menu.", e);
        }
    }

    private void doctorMenu() {
        System.out.println("\n--- Doctor Management ---");
        System.out.println("1. Add Doctor");
        System.out.println("2. View All Doctors");
        System.out.println("3. Search Doctor by ID");
        System.out.println("4. Update Doctor");
        System.out.println("5. Delete Doctor");
        System.out.println("0. Back");
        int choice = readInt("Choice: ");
        try {
            switch (choice) {
                case 1: addDoctor();        break;
                case 2: viewAllDoctors();   break;
                case 3: searchDoctor();     break;
                case 4: updateDoctor();     break;
                case 5: deleteDoctor();     break;
                case 0: return;
                default: System.out.println("Invalid choice.");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Validation error: " + e.getMessage());
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Unexpected error in doctor menu.", e);
        }
    }

    private void appointmentMenu() {
        System.out.println("\n--- Appointment Management ---");
        System.out.println("1. Book Appointment");
        System.out.println("2. View Appointments");
        System.out.println("3. Cancel Appointment");
        System.out.println("0. Back");
        int choice = readInt("Choice: ");
        try {
            switch (choice) {
                case 1: bookAppointment();      break;
                case 2: viewAppointments();     break;
                case 3: cancelAppointment();    break;
                case 0: return;
                default: System.out.println("Invalid choice.");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Validation error: " + e.getMessage());
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Unexpected error in appointment menu.", e);
        }
    }

    private void medicalRecordMenu() {
        System.out.println("\n--- Medical Records (EHR) ---");
        System.out.println("1. Add Medical Record");
        System.out.println("2. View Patient Medical History");
        System.out.println("0. Back");
        int choice = readInt("Choice: ");
        try {
            switch (choice) {
                case 1: addMedicalRecord();        break;
                case 2: viewPatientMedicalHistory(); break;
                case 0: return;
                default: System.out.println("Invalid choice.");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Validation error: " + e.getMessage());
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Unexpected error in medical record menu.", e);
        }
    }

    private void billingMenu() {
        System.out.println("\n--- Billing ---");
        System.out.println("1. Generate Bill");
        System.out.println("2. View Bill Details");
        System.out.println("0. Back");
        int choice = readInt("Choice: ");
        try {
            switch (choice) {
                case 1: generateBill();    break;
                case 2: viewBillDetails(); break;
                case 0: return;
                default: System.out.println("Invalid choice.");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Validation error: " + e.getMessage());
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Unexpected error in billing menu.", e);
        }
    }

    private void reportsMenu() {
        System.out.println("\n--- Reports ---");
        System.out.println("1. Total Patients Count");
        System.out.println("2. Total Doctors Count");
        System.out.println("3. Appointment Summary");
        System.out.println("0. Back");
        int choice = readInt("Choice: ");
        try {
            switch (choice) {
                case 1:
                    System.out.println("Total Patients: " + patientService.countPatients());
                    break;
                case 2:
                    System.out.println("Total Doctors: " + doctorService.countDoctors());
                    break;
                case 3:
                    int[] s = appointmentService.getAppointmentSummary();
                    System.out.println("Appointment Summary:");
                    System.out.println("  Scheduled: " + s[0]);
                    System.out.println("  Completed: " + s[1]);
                    System.out.println("  Cancelled: " + s[2]);
                    break;
                case 0: return;
                default: System.out.println("Invalid choice.");
            }
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Unexpected error in reports menu.", e);
        }
    }

    // ---------------- Patient ops ----------------

    private void addPatient() {
        String name    = readString("Name: ");
        int    age     = readInt("Age: ");
        String gender  = readString("Gender (M/F/O): ").toUpperCase();
        String phone   = readString("Phone: ");
        String address = readString("Address: ");
        Patient p = new Patient(name, age, gender, phone, address);
        if (patientService.addPatient(p)) {
            System.out.println("Patient added with ID: " + p.getPatientId());
        } else {
            System.out.println("Failed to add patient.");
        }
    }

    private void viewAllPatients() {
        List<Patient> list = patientService.getAllPatients();
        if (list.isEmpty()) {
            System.out.println("No patients found.");
        } else {
            list.forEach(System.out::println);
        }
    }

    private void searchPatient() {
        int id = readInt("Patient ID: ");
        Patient p = patientService.getPatientById(id);
        System.out.println(p != null ? p : "Patient not found.");
    }

    private void updatePatient() {
        int id = readInt("Patient ID to update: ");
        Patient existing = patientService.getPatientById(id);
        if (existing == null) {
            System.out.println("Patient not found.");
            return;
        }
        System.out.println("Existing: " + existing);
        existing.setName(readString("New name: "));
        existing.setAge(readInt("New age: "));
        existing.setGender(readString("New gender (M/F/O): ").toUpperCase());
        existing.setPhone(readString("New phone: "));
        existing.setAddress(readString("New address: "));
        System.out.println(patientService.updatePatient(existing) ? "Updated." : "Update failed.");
    }

    private void deletePatient() {
        int id = readInt("Patient ID to delete: ");
        System.out.println(patientService.deletePatient(id) ? "Deleted." : "Delete failed.");
    }

    // ---------------- Doctor ops ----------------

    private void addDoctor() {
        String name           = readString("Name: ");
        String specialization = readString("Specialization: ");
        String phone          = readString("Phone: ");
        String email          = readString("Email: ");
        Doctor d = new Doctor(name, specialization, phone, email);
        if (doctorService.addDoctor(d)) {
            System.out.println("Doctor added with ID: " + d.getDoctorId());
        } else {
            System.out.println("Failed to add doctor.");
        }
    }

    private void viewAllDoctors() {
        List<Doctor> list = doctorService.getAllDoctors();
        if (list.isEmpty()) {
            System.out.println("No doctors found.");
        } else {
            list.forEach(System.out::println);
        }
    }

    private void searchDoctor() {
        int id = readInt("Doctor ID: ");
        Doctor d = doctorService.getDoctorById(id);
        System.out.println(d != null ? d : "Doctor not found.");
    }

    private void updateDoctor() {
        int id = readInt("Doctor ID to update: ");
        Doctor existing = doctorService.getDoctorById(id);
        if (existing == null) {
            System.out.println("Doctor not found.");
            return;
        }
        System.out.println("Existing: " + existing);
        existing.setName(readString("New name: "));
        existing.setSpecialization(readString("New specialization: "));
        existing.setPhone(readString("New phone: "));
        existing.setEmail(readString("New email: "));
        System.out.println(doctorService.updateDoctor(existing) ? "Updated." : "Update failed.");
    }

    private void deleteDoctor() {
        int id = readInt("Doctor ID to delete: ");
        System.out.println(doctorService.deleteDoctor(id) ? "Deleted." : "Delete failed.");
    }

    // ---------------- Appointment ops ----------------

    private void bookAppointment() {
        int patientId = readInt("Patient ID: ");
        int doctorId  = readInt("Doctor ID: ");
        Date date     = Date.valueOf(readString("Appointment date (YYYY-MM-DD): "));
        Time time     = Time.valueOf(readString("Appointment time (HH:MM:SS): "));
        Appointment a = new Appointment(patientId, doctorId, date, time, "SCHEDULED");
        if (appointmentService.bookAppointment(a)) {
            System.out.println("Appointment booked with ID: " + a.getAppointmentId());
        } else {
            System.out.println("Failed to book appointment.");
        }
    }

    private void viewAppointments() {
        List<Appointment> list = appointmentService.getAllAppointments();
        if (list.isEmpty()) {
            System.out.println("No appointments found.");
        } else {
            list.forEach(System.out::println);
        }
    }

    private void cancelAppointment() {
        int id = readInt("Appointment ID to cancel: ");
        System.out.println(appointmentService.cancelAppointment(id) ? "Cancelled." : "Cancel failed.");
    }

    // ---------------- Medical record ops ----------------

    private void addMedicalRecord() {
        int patientId    = readInt("Patient ID: ");
        int doctorId     = readInt("Doctor ID: ");
        String diagnosis = readString("Diagnosis: ");
        String treatment = readString("Treatment: ");
        String notes     = readString("Notes: ");
        Date date        = Date.valueOf(readString("Record date (YYYY-MM-DD): "));
        MedicalRecord r = new MedicalRecord(patientId, doctorId, diagnosis, treatment, notes, date);
        System.out.println(medicalRecordService.addMedicalRecord(r) ? "Record added with ID: " + r.getRecordId()
                                                                    : "Failed to add record.");
    }

    private void viewPatientMedicalHistory() {
        int patientId = readInt("Patient ID: ");
        List<MedicalRecord> list = medicalRecordService.getRecordsByPatient(patientId);
        if (list.isEmpty()) {
            System.out.println("No medical history found.");
        } else {
            list.forEach(System.out::println);
        }
    }

    // ---------------- Billing ops ----------------

    private void generateBill() {
        int patientId            = readInt("Patient ID: ");
        int appointmentIdInput   = readInt("Appointment ID (0 if none): ");
        Integer appointmentId    = appointmentIdInput == 0 ? null : appointmentIdInput;
        BigDecimal consultation  = readBigDecimal("Consultation fee: ");
        BigDecimal medicine      = readBigDecimal("Medicine charges: ");
        BigDecimal other         = readBigDecimal("Other charges: ");
        String paymentStatus     = readString("Payment status (PAID/UNPAID): ").toUpperCase();
        Date billDate            = Date.valueOf(readString("Bill date (YYYY-MM-DD): "));
        Bill bill = new Bill(patientId, appointmentId, consultation, medicine, other,
                             BigDecimal.ZERO, paymentStatus, billDate);
        if (billingService.generateBill(bill)) {
            System.out.println("Bill generated with ID: " + bill.getBillId() + ", total: " + bill.getTotalAmount());
        } else {
            System.out.println("Failed to generate bill.");
        }
    }

    private void viewBillDetails() {
        int billId = readInt("Bill ID: ");
        Bill bill = billingService.getBillById(billId);
        System.out.println(bill != null ? bill : "Bill not found.");
    }

    // ---------------- Input helpers ----------------

    private String readString(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine().trim();
    }

    private int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = scanner.nextLine().trim();
            try {
                return Integer.parseInt(line);
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid integer.");
            }
        }
    }

    private BigDecimal readBigDecimal(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = scanner.nextLine().trim();
            try {
                return new BigDecimal(line);
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }
}
