# Hospital Management System (Java + JDBC + MySQL)

A complete console-based Hospital Management System built with Core Java, JDBC, and MySQL. The project follows a clean layered architecture: **Model → DAO → Service → UI**.

---

## Features

1. **Patient Management** — add, view all, search by ID, update, delete
2. **Doctor Management** — add, view all, search by ID, update, delete
3. **Appointment Management** — book, view, cancel
4. **Medical Records (EHR)** — add record, view a patient's medical history
5. **Billing System** — generate bill (auto-calculates total), view bill details
6. **Reports** — total patients, total doctors, appointment summary by status

Bonus:
- Input validation in the Service layer
- Logging via `java.util.logging`
- Uses `PreparedStatement` everywhere (prevents SQL injection)
- Clean OOP design with separation of concerns

---

## Project Structure

```
hospital-management-system/
├── sql/
│   └── schema.sql                          # MySQL DB + tables + sample data
├── lib/                                    # Drop mysql-connector-j-*.jar here
└── src/
    └── com/hms/
        ├── model/
        │   ├── Patient.java
        │   ├── Doctor.java
        │   ├── Appointment.java
        │   ├── MedicalRecord.java
        │   └── Bill.java
        ├── dao/
        │   ├── PatientDAO.java
        │   ├── DoctorDAO.java
        │   ├── AppointmentDAO.java
        │   ├── MedicalRecordDAO.java
        │   └── BillDAO.java
        ├── service/
        │   ├── PatientService.java
        │   ├── DoctorService.java
        │   ├── AppointmentService.java
        │   ├── MedicalRecordService.java
        │   └── BillingService.java
        ├── util/
        │   └── DBConnection.java
        └── main/
            └── HospitalManagementSystem.java
```

---

## Prerequisites

- **JDK 8+** (tested with JDK 8 and above)
- **MySQL Server 5.7+** running locally
- **MySQL Connector/J** (JDBC driver), e.g. `mysql-connector-j-8.x.x.jar`
  - Download from: https://dev.mysql.com/downloads/connector/j/
  - Place the `.jar` inside the `lib/` folder.

---

## Setup Instructions

### 1. Create the database

Open MySQL and run the schema script:

```bash
mysql -u root -p < sql/schema.sql
```

This creates a database called `hospital_db` with all required tables and a few sample rows.

### 2. Configure the JDBC connection

Open `src/com/hms/util/DBConnection.java` and update the constants if your MySQL setup differs:

```java
private static final String URL      = "jdbc:mysql://localhost:3306/hospital_db?useSSL=false&serverTimezone=UTC";
private static final String USER     = "root";
private static final String PASSWORD = "root";
```

### 3. Add the MySQL JDBC driver

Drop `mysql-connector-j-8.x.x.jar` into the `lib/` directory.

---

## Compile and Run

From the `hospital-management-system/` directory:

### Linux / macOS

```bash
# 1. Compile all .java files into ./out
mkdir -p out
javac -d out $(find src -name "*.java")

# 2. Run the menu-driven application
java -cp "out:lib/*" com.hms.main.HospitalManagementSystem
```

### Windows (cmd)

```bat
:: 1. Compile
mkdir out
dir /s /B src\*.java > sources.txt
javac -d out @sources.txt

:: 2. Run
java -cp "out;lib\*" com.hms.main.HospitalManagementSystem
```

---

## Using the App

You'll see a main menu like:

```
========== HOSPITAL MANAGEMENT SYSTEM ==========
1. Patient Management
2. Doctor Management
3. Appointment Management
4. Medical Records
5. Billing
6. Reports
0. Exit
=================================================
```

Each sub-menu walks you through prompts. Dates use `YYYY-MM-DD` and times use `HH:MM:SS`.

---

## Notes

- All SQL is parameterized with `PreparedStatement`.
- The `BillingService` automatically computes `total_amount = consultation + medicine + other` before saving.
- Foreign keys cascade-delete dependent rows (deleting a patient removes their appointments, records, and bills).
- Appointment cancellation is a soft cancel (status set to `CANCELLED`), so it remains in reports.
