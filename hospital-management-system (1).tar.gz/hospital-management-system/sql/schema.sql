-- =====================================================================
-- Hospital Management System - MySQL Database Schema
-- =====================================================================

DROP DATABASE IF EXISTS hospital_db;
CREATE DATABASE hospital_db;
USE hospital_db;

-- ---------------------------------------------------------------------
-- Patients
-- ---------------------------------------------------------------------
CREATE TABLE patients (
    patient_id      INT AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(100)        NOT NULL,
    age             INT                 NOT NULL,
    gender          ENUM('M','F','O')   NOT NULL,
    phone           VARCHAR(15)         NOT NULL,
    address         VARCHAR(255),
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ---------------------------------------------------------------------
-- Doctors
-- ---------------------------------------------------------------------
CREATE TABLE doctors (
    doctor_id       INT AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(100)        NOT NULL,
    specialization  VARCHAR(100)        NOT NULL,
    phone           VARCHAR(15)         NOT NULL,
    email           VARCHAR(100),
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ---------------------------------------------------------------------
-- Appointments
-- ---------------------------------------------------------------------
CREATE TABLE appointments (
    appointment_id     INT AUTO_INCREMENT PRIMARY KEY,
    patient_id         INT NOT NULL,
    doctor_id          INT NOT NULL,
    appointment_date   DATE NOT NULL,
    appointment_time   TIME NOT NULL,
    status             ENUM('SCHEDULED','COMPLETED','CANCELLED') DEFAULT 'SCHEDULED',
    created_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_app_patient FOREIGN KEY (patient_id) REFERENCES patients(patient_id) ON DELETE CASCADE,
    CONSTRAINT fk_app_doctor  FOREIGN KEY (doctor_id)  REFERENCES doctors(doctor_id)  ON DELETE CASCADE
);

-- ---------------------------------------------------------------------
-- Medical Records (EHR)
-- ---------------------------------------------------------------------
CREATE TABLE medical_records (
    record_id       INT AUTO_INCREMENT PRIMARY KEY,
    patient_id      INT NOT NULL,
    doctor_id       INT NOT NULL,
    diagnosis       VARCHAR(255) NOT NULL,
    treatment       VARCHAR(255) NOT NULL,
    notes           TEXT,
    record_date     DATE NOT NULL,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_rec_patient FOREIGN KEY (patient_id) REFERENCES patients(patient_id) ON DELETE CASCADE,
    CONSTRAINT fk_rec_doctor  FOREIGN KEY (doctor_id)  REFERENCES doctors(doctor_id)  ON DELETE CASCADE
);

-- ---------------------------------------------------------------------
-- Bills
-- ---------------------------------------------------------------------
CREATE TABLE bills (
    bill_id         INT AUTO_INCREMENT PRIMARY KEY,
    patient_id      INT NOT NULL,
    appointment_id  INT,
    consultation_fee  DECIMAL(10,2) NOT NULL DEFAULT 0,
    medicine_charges  DECIMAL(10,2) NOT NULL DEFAULT 0,
    other_charges     DECIMAL(10,2) NOT NULL DEFAULT 0,
    total_amount      DECIMAL(10,2) NOT NULL,
    payment_status    ENUM('PAID','UNPAID') DEFAULT 'UNPAID',
    bill_date         DATE NOT NULL,
    created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_bill_patient     FOREIGN KEY (patient_id)     REFERENCES patients(patient_id)        ON DELETE CASCADE,
    CONSTRAINT fk_bill_appointment FOREIGN KEY (appointment_id) REFERENCES appointments(appointment_id) ON DELETE SET NULL
);

-- ---------------------------------------------------------------------
-- Sample Seed Data (optional)
-- ---------------------------------------------------------------------
INSERT INTO patients (name, age, gender, phone, address) VALUES
('Ravi Kumar', 32, 'M', '9876543210', 'MG Road, Bangalore'),
('Anita Sharma', 28, 'F', '9123456780', 'Sector 12, Delhi');

INSERT INTO doctors (name, specialization, phone, email) VALUES
('Dr. Suresh Mehta', 'Cardiologist', '9988776655', 'suresh@hospital.com'),
('Dr. Priya Verma', 'Dermatologist', '9876501234', 'priya@hospital.com');
